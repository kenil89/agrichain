import React, { createContext, useContext, useState, useEffect } from 'react';
import { useWallet } from './WalletContext';

interface ContractContextType {
  contract: any;
  contractAddress: string;
  isContractReady: boolean;
}

const ContractContext = createContext<ContractContextType>({
  contract: null,
  contractAddress: '',
  isContractReady: false,
});

export const useContract = () => useContext(ContractContext);

interface ContractProviderProps {
  children: React.ReactNode;
}

// Your contract ABI (simplified for demo)
const CONTRACT_ABI = [
  {
    "inputs": [
      {"name": "stockId", "type": "string"},
      {"name": "name", "type": "string"},
      {"name": "qty", "type": "uint256"},
      {"name": "price", "type": "uint256"}
    ],
    "name": "createFarmerStock",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {"name": "parentId", "type": "string"},
      {"name": "newStockId", "type": "string"},
      {"name": "qty", "type": "uint256"}
    ],
    "name": "distributorBuy",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {"name": "parentId", "type": "string"},
      {"name": "newStockId", "type": "string"},
      {"name": "qty", "type": "uint256"},
      {"name": "newPrice", "type": "uint256"},
      {"name": "buyer", "type": "address"}
    ],
    "name": "sellStock",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"name": "stockId", "type": "string"}],
    "name": "getStockHistory",
    "outputs": [
      {"name": "", "type": "string[]"},
      {"name": "", "type": "uint256[]"},
      {"name": "", "type": "uint256[]"}
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{"name": "", "type": "string"}],
    "name": "stocks",
    "outputs": [
      {"name": "stockId", "type": "string"},
      {"name": "name", "type": "string"},
      {"name": "quantity", "type": "uint256"},
      {"name": "unitPrice", "type": "uint256"},
      {"name": "owner", "type": "address"},
      {"name": "parentId", "type": "string"}
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

// Replace with your deployed contract address
const CONTRACT_ADDRESS = "0x1234567890123456789012345678901234567890";

export const ContractProvider: React.FC<ContractProviderProps> = ({ children }) => {
  const { isConnected } = useWallet();
  const [contract, setContract] = useState<any>(null);
  const [isContractReady, setIsContractReady] = useState(false);

  useEffect(() => {
    initializeContract();
  }, [isConnected]);

  const initializeContract = async () => {
    if (!isConnected || typeof window === 'undefined' || !window.ethereum) {
      return;
    }

    try {
      // For demo purposes, we'll create a mock contract object
      // In production, you would use ethers.js or web3.js
      const mockContract = {
        createFarmerStock: async (stockId: string, name: string, qty: number, price: number) => {
          console.log('Creating farmer stock:', { stockId, name, qty, price });
          // Simulate blockchain transaction
          return new Promise(resolve => setTimeout(resolve, 2000));
        },
        distributorBuy: async (parentId: string, newStockId: string, qty: number) => {
          console.log('Distributor buying:', { parentId, newStockId, qty });
          return new Promise(resolve => setTimeout(resolve, 2000));
        },
        sellStock: async (parentId: string, newStockId: string, qty: number, newPrice: number, buyer: string) => {
          console.log('Selling stock:', { parentId, newStockId, qty, newPrice, buyer });
          return new Promise(resolve => setTimeout(resolve, 2000));
        },
        getStockHistory: async (stockId: string) => {
          console.log('Getting stock history for:', stockId);
          return [
            ['1', '1.1'],
            [1000, 1200],
            [500, 50]
          ];
        },
        stocks: async (stockId: string) => {
          console.log('Getting stock info for:', stockId);
          return {
            stockId,
            name: 'Sample Product',
            quantity: 100,
            unitPrice: 1000,
            owner: '0x123...',
            parentId: ''
          };
        }
      };

      setContract(mockContract);
      setIsContractReady(true);
    } catch (error) {
      console.error('Error initializing contract:', error);
    }
  };

  return (
    <ContractContext.Provider
      value={{
        contract,
        contractAddress: CONTRACT_ADDRESS,
        isContractReady,
      }}
    >
      {children}
    </ContractContext.Provider>
  );
};