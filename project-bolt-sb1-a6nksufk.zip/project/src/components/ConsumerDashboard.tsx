import React, { useState } from 'react';
import { Search, History, ShoppingCart, TrendingUp, Hash } from 'lucide-react';

interface ProductHistory {
  stockId: string;
  name: string;
  currentPrice: string;
  history: {
    stage: string;
    price: string;
    quantity: string;
    owner: string;
    timestamp: string;
  }[];
}

const ConsumerDashboard: React.FC = () => {
  const [searchId, setSearchId] = useState('');
  const [productHistory, setProductHistory] = useState<ProductHistory | null>(null);
  const [loading, setLoading] = useState(false);

  // Sample data for demonstration
  const availableProducts = [
    {
      stockId: '1.1',
      name: 'Organic Tomatoes',
      quantity: '50',
      currentPrice: '1200',
      distributor: '0xDist1...',
      originalPrice: '1000',
      margin: '20%',
    },
    {
      stockId: '2.1',
      name: 'Fresh Lettuce',
      quantity: '30',
      currentPrice: '960',
      distributor: '0xDist2...',
      originalPrice: '800',
      margin: '20%',
    },
  ];

  const handleTrackProduct = async () => {
    if (!searchId.trim()) return;

    setLoading(true);
    try {
      // Simulate API call to get product history
      setTimeout(() => {
        const sampleHistory: ProductHistory = {
          stockId: searchId,
          name: 'Organic Tomatoes',
          currentPrice: '1200',
          history: [
            {
              stage: 'Farmer',
              price: '1000',
              quantity: '500',
              owner: '0xFarmer123...',
              timestamp: '2025-01-08 10:00',
            },
            {
              stage: 'Distributor',
              price: '1200',
              quantity: '50',
              owner: '0xDist456...',
              timestamp: '2025-01-09 14:30',
            },
          ],
        };
        setProductHistory(sampleHistory);
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error tracking product:', error);
      setLoading(false);
    }
  };

  const calculateMargin = (current: string, original: string) => {
    const currentPrice = parseInt(current);
    const originalPrice = parseInt(original);
    return (((currentPrice - originalPrice) / originalPrice) * 100).toFixed(1);
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Consumer Dashboard</h1>
        <p className="text-gray-600">Track product history and purchase from distributors</p>
      </div>

      {/* Product Tracking */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8 border-2 border-green-100">
        <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
          <Search className="h-6 w-6 mr-2 text-green-600" />
          Track Product History
        </h2>
        <div className="flex space-x-4">
          <input
            type="text"
            placeholder="Enter Stock ID (e.g., 1.1, 2.1)"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
          <button
            onClick={handleTrackProduct}
            disabled={loading || !searchId.trim()}
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors"
          >
            {loading ? 'Tracking...' : 'Track Product'}
          </button>
        </div>
      </div>

      {/* Product History Results */}
      {productHistory && (
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
            <History className="h-6 w-6 mr-2 text-blue-600" />
            Product Journey: {productHistory.name}
          </h3>
          
          <div className="space-y-4">
            {productHistory.history.map((entry, index) => (
              <div key={index} className="flex items-center space-x-4">
                <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1 bg-stone-50 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-semibold text-gray-800">{entry.stage}</h4>
                      <p className="text-sm text-gray-600">Owner: {entry.owner}</p>
                      <p className="text-sm text-gray-500">{entry.timestamp}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-gray-800">{entry.price} Wei/kg</p>
                      <p className="text-sm text-gray-600">{entry.quantity} kg</p>
                      {index > 0 && (
                        <p className="text-sm text-red-600">
                          +{calculateMargin(entry.price, productHistory.history[0].price)}% from origin
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                {index < productHistory.history.length - 1 && (
                  <div className="flex-shrink-0 w-8 text-center">
                    <div className="w-px h-6 bg-gray-300 mx-auto"></div>
                    <div className="text-gray-400 text-xs">↓</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Available Products */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <ShoppingCart className="h-7 w-7 mr-2 text-green-600" />
          Available Products
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {availableProducts.map((product) => (
            <div key={product.stockId} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-800">{product.name}</h3>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Hash className="h-4 w-4" />
                  <span>Stock ID: {product.stockId}</span>
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Available:</span>
                  <span className="font-medium">{product.quantity} kg</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Current Price:</span>
                  <span className="font-bold text-green-600">{product.currentPrice} Wei/kg</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Original Price:</span>
                  <span className="text-gray-600">{product.originalPrice} Wei/kg</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Price Increase:</span>
                  <div className="flex items-center space-x-1">
                    <TrendingUp className="h-4 w-4 text-orange-500" />
                    <span className="text-orange-600 font-medium">{product.margin}</span>
                  </div>
                </div>
              </div>

              <div className="flex space-x-2">
                <button
                  onClick={() => setSearchId(product.stockId)}
                  className="flex-1 px-4 py-2 border border-green-600 text-green-600 rounded-lg hover:bg-green-50 transition-colors"
                >
                  Track History
                </button>
                <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Purchase
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ConsumerDashboard;