import React from 'react';
import { Users, Truck, ShoppingCart } from 'lucide-react';
import { UserRole } from '../App';
import { useWallet } from '../context/WalletContext';

interface RoleSelectorProps {
  onSelectRole: (role: UserRole) => void;
}

const RoleSelector: React.FC<RoleSelectorProps> = ({ onSelectRole }) => {
  const { isConnected } = useWallet();

  const roles = [
    {
      id: 'farmer' as const,
      title: 'Farmer',
      description: 'List your agricultural products on the blockchain',
      icon: Users,
      color: 'green',
    },
    {
      id: 'distributor' as const,
      title: 'Distributor',
      description: 'Buy products from farmers and resell to consumers',
      icon: Truck,
      color: 'blue',
    },
    {
      id: 'consumer' as const,
      title: 'Consumer',
      description: 'Track product history and purchase from distributors',
      icon: ShoppingCart,
      color: 'purple',
    },
  ];

  if (!isConnected) {
    return (
      <div className="max-w-2xl mx-auto text-center">
        <div className="bg-white rounded-xl shadow-lg p-8 border-2 border-green-100">
          <div className="mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="h-10 w-10 text-green-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Welcome to AgriChain</h2>
            <p className="text-gray-600">
              Connect your MetaMask wallet to access the agricultural supply chain platform
            </p>
          </div>
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-yellow-800 text-sm">
              Please connect your wallet to continue and select your role in the supply chain.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Choose Your Role</h2>
        <p className="text-gray-600">
          Select your role in the agricultural supply chain to get started
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {roles.map((role) => {
          const IconComponent = role.icon;
          return (
            <button
              key={role.id}
              onClick={() => onSelectRole(role.id)}
              className="group bg-white rounded-xl shadow-lg p-6 border-2 border-transparent hover:border-green-200 hover:shadow-xl transition-all duration-300 text-left"
            >
              <div className="flex flex-col items-center text-center">
                <div className={`w-16 h-16 bg-${role.color}-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <IconComponent className={`h-8 w-8 text-${role.color}-600`} />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">{role.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{role.description}</p>
              </div>
              <div className="mt-4 flex justify-center">
                <div className="px-4 py-2 bg-green-100 text-green-700 rounded-lg text-sm font-medium group-hover:bg-green-200 transition-colors">
                  Enter as {role.title}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default RoleSelector;