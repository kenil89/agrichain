import React from 'react';
import { Wallet, LogOut, User } from 'lucide-react';
import { useWallet } from '../context/WalletContext';

const WalletConnect: React.FC = () => {
  const { account, isConnected, connectWallet, disconnectWallet } = useWallet();

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  if (isConnected && account) {
    return (
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-2 px-4 py-2 bg-green-100 text-green-800 rounded-lg">
          <User className="h-4 w-4" />
          <span className="text-sm font-medium">{formatAddress(account)}</span>
        </div>
        <button
          onClick={disconnectWallet}
          className="flex items-center space-x-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors"
        >
          <LogOut className="h-4 w-4" />
          <span>Disconnect</span>
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={connectWallet}
      className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
    >
      <Wallet className="h-5 w-5" />
      <span>Connect Wallet</span>
    </button>
  );
};

export default WalletConnect;