import React from 'react';
import { Sprout, QrCode, Home } from 'lucide-react';
import WalletConnect from './WalletConnect';
import { UserRole } from '../App';

interface HeaderProps {
  selectedRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onScannerToggle: () => void;
  showScanner: boolean;
}

const Header: React.FC<HeaderProps> = ({ 
  selectedRole, 
  onRoleChange, 
  onScannerToggle, 
  showScanner 
}) => {
  return (
    <header className="bg-white shadow-sm border-b-2 border-green-100">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-green-100 rounded-lg">
                <Sprout className="h-8 w-8 text-green-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">AgriChain</h1>
                <p className="text-sm text-green-600">Blockchain Supply Chain</p>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={onScannerToggle}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                showScanner
                  ? 'bg-green-600 text-white'
                  : 'bg-green-100 text-green-700 hover:bg-green-200'
              }`}
            >
              <QrCode className="h-5 w-5" />
              <span>Track Product</span>
            </button>

            {selectedRole && (
              <button
                onClick={() => onRoleChange(null)}
                className="flex items-center space-x-2 px-4 py-2 bg-stone-100 text-stone-700 rounded-lg hover:bg-stone-200 transition-colors"
              >
                <Home className="h-5 w-5" />
                <span>Home</span>
              </button>
            )}

            <WalletConnect />
          </div>
        </div>

        {selectedRole && (
          <div className="mt-4 flex items-center justify-center">
            <div className="px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium capitalize">
              {selectedRole} Dashboard
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;