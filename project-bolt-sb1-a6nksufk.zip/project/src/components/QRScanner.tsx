import React, { useState } from 'react';
import { X, Search, Package } from 'lucide-react';

interface QRScannerProps {
  onClose: () => void;
}

const QRScanner: React.FC<QRScannerProps> = ({ onClose }) => {
  const [scannedId, setScannedId] = useState('');
  const [searchResult, setSearchResult] = useState<any>(null);

  const handleManualSearch = () => {
    if (!scannedId.trim()) return;

    // Simulate blockchain lookup
    const mockResult = {
      stockId: scannedId,
      name: 'Organic Tomatoes',
      currentOwner: '0xABC123...',
      currentPrice: '1200',
      status: 'In Transit',
      history: [
        { stage: 'Farmer', date: '2025-01-08', price: '1000' },
        { stage: 'Distributor', date: '2025-01-09', price: '1200' },
      ],
    };
    setSearchResult(mockResult);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full mx-4">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-800">Track Product</h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Enter Stock ID or scan QR code
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={scannedId}
                onChange={(e) => setScannedId(e.target.value)}
                placeholder="e.g., 1.1, 2.1"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              />
              <button
                onClick={handleManualSearch}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                <Search className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* QR Scanner Placeholder */}
          <div className="mb-6 bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">QR Scanner would be here</p>
            <p className="text-gray-400 text-xs">Use manual input above for now</p>
          </div>

          {searchResult && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h3 className="font-semibold text-green-800 mb-2">Product Found!</h3>
              <div className="space-y-1 text-sm">
                <p><span className="font-medium">Name:</span> {searchResult.name}</p>
                <p><span className="font-medium">Stock ID:</span> {searchResult.stockId}</p>
                <p><span className="font-medium">Current Owner:</span> {searchResult.currentOwner}</p>
                <p><span className="font-medium">Current Price:</span> {searchResult.currentPrice} Wei</p>
                <p><span className="font-medium">Status:</span> {searchResult.status}</p>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-gray-200">
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
          >
            Close Scanner
          </button>
        </div>
      </div>
    </div>
  );
};

export default QRScanner;