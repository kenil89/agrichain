import React, { useState, useEffect } from 'react';
import { Plus, Package, DollarSign, Hash } from 'lucide-react';
import { useContract } from '../context/ContractContext';
import { useWallet } from '../context/WalletContext';

interface Stock {
  stockId: string;
  name: string;
  quantity: string;
  unitPrice: string;
  owner: string;
}

const FarmerDashboard: React.FC = () => {
  const { contract } = useContract();
  const { account } = useWallet();
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [nextId, setNextId] = useState(1);

  const [formData, setFormData] = useState({
    name: '',
    quantity: '',
    price: '',
  });

  useEffect(() => {
    loadFarmerStocks();
  }, [contract, account]);

  const loadFarmerStocks = async () => {
    if (!contract || !account) return;

    try {
      // Load farmer's stocks (in a real app, you'd have a way to query by owner)
      const farmerStocks: Stock[] = [];
      setStocks(farmerStocks);
    } catch (error) {
      console.error('Error loading stocks:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contract) {
      alert('Please connect to the blockchain first');
      return;
    }

    setLoading(true);
    try {
      const stockId = nextId.toString();
      const quantity = parseInt(formData.quantity);
      const price = parseInt(formData.price);

      await contract.createFarmerStock(stockId, formData.name, quantity, price);
      
      setNextId(nextId + 1);
      setFormData({ name: '', quantity: '', price: '' });
      setShowForm(false);
      loadFarmerStocks();
      
      alert('Stock created successfully!');
    } catch (error) {
      console.error('Error creating stock:', error);
      alert('Error creating stock. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Farmer Dashboard</h1>
          <p className="text-gray-600">Manage your agricultural products</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Plus className="h-5 w-5" />
          <span>List New Product</span>
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8 border-2 border-green-100">
          <h2 className="text-xl font-bold text-gray-800 mb-4">List New Product</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Product Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="e.g., Organic Tomatoes"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantity (kg)
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Price per kg (Wei)
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="1000"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Hash className="h-4 w-4" />
                <span>Stock ID will be: {nextId}</span>
              </div>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                >
                  {loading ? 'Creating...' : 'List Product'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stocks.length === 0 ? (
          <div className="col-span-full">
            <div className="bg-white rounded-xl shadow-lg p-12 text-center border-2 border-dashed border-gray-200">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No Products Listed</h3>
              <p className="text-gray-500 mb-4">
                Start by listing your first agricultural product on the blockchain
              </p>
              <button
                onClick={() => setShowForm(true)}
                className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                List Your First Product
              </button>
            </div>
          </div>
        ) : (
          stocks.map((stock) => (
            <div key={stock.stockId} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">{stock.name}</h3>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <Hash className="h-4 w-4" />
                    <span>ID: {stock.stockId}</span>
                  </div>
                </div>
                <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                  Listed
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Quantity:</span>
                  <span className="font-medium">{stock.quantity} kg</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Price per kg:</span>
                  <span className="font-medium">{stock.unitPrice} Wei</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Total Value:</span>
                  <span className="font-bold text-green-600">
                    {parseInt(stock.quantity) * parseInt(stock.unitPrice)} Wei
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FarmerDashboard;