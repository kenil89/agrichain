import React, { useState, useEffect } from 'react';
import { Package, ShoppingBag, TrendingUp, Hash } from 'lucide-react';
import { useContract } from '../context/ContractContext';
import { useWallet } from '../context/WalletContext';

interface Stock {
  stockId: string;
  name: string;
  quantity: string;
  unitPrice: string;
  owner: string;
}

const DistributorDashboard: React.FC = () => {
  const { contract } = useContract();
  const { account } = useWallet();
  const [availableStocks, setAvailableStocks] = useState<Stock[]>([]);
  const [myStocks, setMyStocks] = useState<Stock[]>([]);
  const [showBuyForm, setShowBuyForm] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [distributorCounter, setDistributorCounter] = useState(1);

  const [buyForm, setBuyForm] = useState({
    quantity: '',
  });

  useEffect(() => {
    loadStocks();
  }, [contract, account]);

  const loadStocks = async () => {
    if (!contract || !account) return;

    try {
      // In a real app, you'd query the blockchain for available stocks
      // For demo, we'll show some sample data
      const sampleStocks: Stock[] = [
        {
          stockId: '1',
          name: 'Organic Tomatoes',
          quantity: '500',
          unitPrice: '1000',
          owner: '0x1234...',
        },
        {
          stockId: '2',
          name: 'Fresh Lettuce',
          quantity: '300',
          unitPrice: '800',
          owner: '0x5678...',
        },
      ];
      setAvailableStocks(sampleStocks);
    } catch (error) {
      console.error('Error loading stocks:', error);
    }
  };

  const handleBuy = async (parentStockId: string) => {
    if (!contract) {
      alert('Please connect to the blockchain first');
      return;
    }

    setLoading(true);
    try {
      const newStockId = `${parentStockId}.${distributorCounter}`;
      const quantity = parseInt(buyForm.quantity);

      await contract.distributorBuy(parentStockId, newStockId, quantity);
      
      setDistributorCounter(distributorCounter + 1);
      setBuyForm({ quantity: '' });
      setShowBuyForm(null);
      loadStocks();
      
      alert('Purchase successful!');
    } catch (error) {
      console.error('Error buying stock:', error);
      alert('Error processing purchase. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Distributor Dashboard</h1>
        <p className="text-gray-600">Buy from farmers and manage your inventory</p>
      </div>

      {/* Statistics */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Available Products</p>
              <p className="text-2xl font-bold text-gray-800">{availableStocks.length}</p>
            </div>
            <Package className="h-8 w-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">My Inventory</p>
              <p className="text-2xl font-bold text-gray-800">{myStocks.length}</p>
            </div>
            <ShoppingBag className="h-8 w-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Next Stock ID</p>
              <p className="text-2xl font-bold text-gray-800">X.{distributorCounter}</p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Available Stocks */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Available from Farmers</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {availableStocks.map((stock) => (
            <div key={stock.stockId} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-800">{stock.name}</h3>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Hash className="h-4 w-4" />
                  <span>Farmer ID: {stock.stockId}</span>
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Available:</span>
                  <span className="font-medium">{stock.quantity} kg</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Price per kg:</span>
                  <span className="font-medium">{stock.unitPrice} Wei</span>
                </div>
              </div>

              {showBuyForm === stock.stockId ? (
                <div className="space-y-3">
                  <input
                    type="number"
                    placeholder="Quantity to buy (kg)"
                    min="1"
                    max={stock.quantity}
                    value={buyForm.quantity}
                    onChange={(e) => setBuyForm({ quantity: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                  <div className="text-sm text-gray-600 mb-2">
                    New Stock ID: {stock.stockId}.{distributorCounter}
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setShowBuyForm(null)}
                      className="flex-1 px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleBuy(stock.stockId)}
                      disabled={loading || !buyForm.quantity}
                      className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    >
                      {loading ? 'Buying...' : 'Buy Now'}
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowBuyForm(stock.stockId)}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Buy from Farmer
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* My Inventory */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800 mb-4">My Inventory</h2>
        {myStocks.length === 0 ? (
          <div className="bg-white rounded-xl shadow-lg p-12 text-center border-2 border-dashed border-gray-200">
            <ShoppingBag className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No Inventory Yet</h3>
            <p className="text-gray-500">
              Start by purchasing products from farmers to build your inventory
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myStocks.map((stock) => (
              <div key={stock.stockId} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{stock.name}</h3>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Hash className="h-4 w-4" />
                      <span>ID: {stock.stockId}</span>
                    </div>
                  </div>
                  <div className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                    In Stock
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Quantity:</span>
                    <span className="font-medium">{stock.quantity} kg</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Cost per kg:</span>
                    <span className="font-medium">{stock.unitPrice} Wei</span>
                  </div>
                </div>
                
                <button className="w-full mt-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Sell to Consumer
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DistributorDashboard;