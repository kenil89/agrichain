import React, { useState, useEffect } from 'react';
import { Sprout, Wallet, QrCode, Users, Truck, ShoppingCart } from 'lucide-react';
import Header from './components/Header';
import WalletConnect from './components/WalletConnect';
import RoleSelector from './components/RoleSelector';
import FarmerDashboard from './components/FarmerDashboard';
import DistributorDashboard from './components/DistributorDashboard';
import ConsumerDashboard from './components/ConsumerDashboard';
import QRScanner from './components/QRScanner';
import { WalletProvider } from './context/WalletContext';
import { ContractProvider } from './context/ContractContext';

export type UserRole = 'farmer' | 'distributor' | 'consumer' | null;

function App() {
  const [selectedRole, setSelectedRole] = useState<UserRole>(null);
  const [showScanner, setShowScanner] = useState(false);

  const renderDashboard = () => {
    switch (selectedRole) {
      case 'farmer':
        return <FarmerDashboard />;
      case 'distributor':
        return <DistributorDashboard />;
      case 'consumer':
        return <ConsumerDashboard />;
      default:
        return <RoleSelector onSelectRole={setSelectedRole} />;
    }
  };

  return (
    <WalletProvider>
      <ContractProvider>
        <div className="min-h-screen bg-stone-50">
          <Header 
            selectedRole={selectedRole} 
            onRoleChange={setSelectedRole}
            onScannerToggle={() => setShowScanner(!showScanner)}
            showScanner={showScanner}
          />
          
          {showScanner && <QRScanner onClose={() => setShowScanner(false)} />}
          
          <main className="container mx-auto px-4 py-8">
            {renderDashboard()}
          </main>
        </div>
      </ContractProvider>
    </WalletProvider>
  );
}

export default App;